package decisiontree;



public class DecisionNode extends Node {
	public int attribute;
	public Node[] nodes;
	public String[] attributeValues;
}
