package decisiontree;


public class ClassNode extends Node{
	public String className;
}
