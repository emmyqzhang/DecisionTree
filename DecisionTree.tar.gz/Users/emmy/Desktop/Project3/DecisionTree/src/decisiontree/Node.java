package decisiontree;


public  abstract class Node {

}
